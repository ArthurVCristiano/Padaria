Este repositório foi criado para documentar e armazenar os arquivos do trabalho prático da matéria de Programção Orientada a Objetos II  Do curso de Engenharia de Software da UDESC CEAVI,
