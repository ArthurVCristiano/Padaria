/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package guis;

import entity.Cliente;
import entity.Pessoa;
import entity.Produto;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JLabel;

/**
 *
 * @author arthu
 */
public class CatalogoCliente extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CatalogoCliente.class.getName());
    private String[] produtosCatalogo = {" 01. Pão Francês" , " 02. Pão de Queijo" , " 03. Pão Doce (Com farofa) " , "04. Pão Doce (Liso)" , " 05. Café Expresso ", " 06. Rosca Tradicional " , " 07. Bolo de Cenoura "};
    private ArrayList<Produto> produtosCarrinho;
    private int contPaoFrances = 0; private int contPaoQueijo = 0;private int contPaoDoce = 0;private int contPaoLiso = 0;private int contCafeExpresso = 0;private int contRoscaTradicional = 0;private int contBoloCenoura = 0;
    private double totPagamento = 0;
    
    
    public CatalogoCliente() {
        this.produtosCarrinho =  new ArrayList<Produto>();
        
        initComponents();
        
        lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }

    
    public String[] getCtalogoList(){
	return this.produtosCatalogo;
    }

    public void addCarrinho(Produto produto){
	this.produtosCarrinho.add(produto);
    }
    
    private void atualizarPainelPedidos() {
    painelPedidos.removeAll();

    painelPedidos.setLayout(new BoxLayout(painelPedidos, BoxLayout.Y_AXIS));
    java.awt.Dimension tamanhoFixo = new java.awt.Dimension(245, 150);

    
    painelPedidos.setMinimumSize(tamanhoFixo);
    painelPedidos.setPreferredSize(tamanhoFixo);
    painelPedidos.setMaximumSize(tamanhoFixo);

    for (Produto p : this.produtosCarrinho) {
        JLabel lbl = new JLabel(p.getQuantidadeProdutosCatalogo() + "x " + p.toString());
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        painelPedidos.add(lbl);
    }

    painelPedidos.revalidate();
    painelPedidos.repaint();
    
    }
    
    public double calculaTotalPagamento(){
        int qtdProdutos = 0; int ptProdutos= 0; double totalAcumulado = 0;
        
        for (Produto p : this.produtosCarrinho) {
                     
            totalAcumulado += (p.getQuantidadeProdutosCatalogo() * p.getValorPonto());
        }
       
       return totalAcumulado;
       
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel12 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btPaoFrances = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btPaoQueijo = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btPaoDoce = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btPaoDoceLiso = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        btCafeExpresso = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btRosca = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        btBoloCenoura = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        painelPedidos = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        lblTotalPedido = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        jLabel12.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("01. Pão Francês ..........................");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 102, 0));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jPanel2.setBackground(new java.awt.Color(255, 204, 168));
        jPanel2.setForeground(new java.awt.Color(255, 204, 168));

        jLabel2.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("01. Pão Francês .......................");

        jLabel3.setFont(new java.awt.Font("Stylus BT", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 102, 0));
        jLabel3.setText("Produtos regastáveis");

        jLabel4.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("02 pt.");

        btPaoFrances.setBackground(new java.awt.Color(0, 102, 0));
        btPaoFrances.setText("+");
        btPaoFrances.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPaoFrancesActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("02. Pão de Queijo ....................");

        jLabel6.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("05 pt.");

        btPaoQueijo.setBackground(new java.awt.Color(0, 102, 0));
        btPaoQueijo.setText("+");
        btPaoQueijo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPaoQueijoActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("04 pt.");

        btPaoDoce.setBackground(new java.awt.Color(0, 102, 0));
        btPaoDoce.setText("+");
        btPaoDoce.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPaoDoceActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("02. Pão de Queijo ..........................");

        jLabel9.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("05 pt.");

        btPaoDoceLiso.setBackground(new java.awt.Color(0, 102, 0));
        btPaoDoceLiso.setText("+");
        btPaoDoceLiso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPaoDoceLisoActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("01. Pão Francês ..........................");

        jLabel13.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("03. Pão Doce (Com farofa) .........");

        jLabel18.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("06. Rosca Tradicional ...............");

        jLabel19.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("04. Pão Doce (Liso) .................");

        jLabel20.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("04 pt.");

        btCafeExpresso.setBackground(new java.awt.Color(0, 102, 0));
        btCafeExpresso.setText("+");
        btCafeExpresso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCafeExpressoActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("05. Café Expresso ...................");

        jLabel22.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("10 pt.");

        btRosca.setBackground(new java.awt.Color(0, 102, 0));
        btRosca.setText("+");
        btRosca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRoscaActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("07. Bolo de Cenoura ................");

        jLabel24.setFont(new java.awt.Font("Stylus BT", 3, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("20 pt.");

        btBoloCenoura.setBackground(new java.awt.Color(0, 102, 0));
        btBoloCenoura.setText("+");
        btBoloCenoura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBoloCenouraActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Stylus BT", 3, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Saldo:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 1, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btPaoDoce, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btPaoDoceLiso, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btPaoFrances, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btPaoQueijo, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btCafeExpresso, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btRosca, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btBoloCenoura, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(btPaoFrances))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(btPaoQueijo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(btPaoDoce)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(btPaoDoceLiso)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(btCafeExpresso)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(btRosca))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24)
                    .addComponent(btBoloCenoura))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        painelPedidos.setBackground(new java.awt.Color(255, 204, 168));
        painelPedidos.setForeground(new java.awt.Color(255, 204, 168));

        javax.swing.GroupLayout painelPedidosLayout = new javax.swing.GroupLayout(painelPedidos);
        painelPedidos.setLayout(painelPedidosLayout);
        painelPedidosLayout.setHorizontalGroup(
            painelPedidosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 245, Short.MAX_VALUE)
        );
        painelPedidosLayout.setVerticalGroup(
            painelPedidosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        jButton9.setBackground(new java.awt.Color(102, 153, 0));
        jButton9.setForeground(new java.awt.Color(0, 51, 0));
        jButton9.setText("Confirmar Resgate");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 204, 168));
        jPanel3.setForeground(new java.awt.Color(255, 204, 168));

        jLabel17.setFont(new java.awt.Font("Stylus BT", 3, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(153, 102, 0));
        jLabel17.setText("Pedidos");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(85, Short.MAX_VALUE)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 204, 168));
        jPanel4.setForeground(new java.awt.Color(255, 204, 168));

        jLabel25.setFont(new java.awt.Font("Stylus BT", 3, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(153, 102, 0));
        jLabel25.setText("Total:");

        lblTotalPedido.setBackground(new java.awt.Color(204, 153, 0));
        lblTotalPedido.setForeground(new java.awt.Color(204, 153, 0));
        lblTotalPedido.setText( calculaTotalPagamento() + " pts ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTotalPedido, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel25)
                    .addComponent(lblTotalPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jButton1.setBackground(new java.awt.Color(255, 102, 102));
        jButton1.setForeground(new java.awt.Color(51, 0, 0));
        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(painelPedidos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(painelPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 3, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void btPaoFrancesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPaoFrancesActionPerformed
    Produto paoFrances = new Produto("Pão Francês", 1, 2);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(paoFrances.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(paoFrances);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btPaoFrancesActionPerformed

    private void btPaoQueijoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPaoQueijoActionPerformed
    Produto paoQueijo = new Produto("Pão de Queijo", 1, 5);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(paoQueijo.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(paoQueijo);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btPaoQueijoActionPerformed

    private void btPaoDoceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPaoDoceActionPerformed
    Produto paoDoce = new Produto("Pão Doce com Farofa", 1, 4);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(paoDoce.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(paoDoce);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btPaoDoceActionPerformed

    private void btPaoDoceLisoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPaoDoceLisoActionPerformed
    Produto paoDoceLiso = new Produto("Pão Doce Liso", 1, 5);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(paoDoceLiso.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(paoDoceLiso);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btPaoDoceLisoActionPerformed

    private void btCafeExpressoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCafeExpressoActionPerformed
    Produto cafeExpresso = new Produto("Café Expresso", 1, 4);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(cafeExpresso.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(cafeExpresso);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btCafeExpressoActionPerformed

    private void btRoscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRoscaActionPerformed
    Produto rosca = new Produto("Rosca Tradicional", 1, 10);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(rosca.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(rosca);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btRoscaActionPerformed

    private void btBoloCenouraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBoloCenouraActionPerformed
    Produto boloCenoura = new Produto("Bolo de Cenoura", 1, 20);
    boolean produtoJaExiste = false;

    for (Produto p : this.produtosCarrinho) {
        if (p.getNome().equals(boloCenoura.getNome())) {
            p.adicionaCarrinho(); 
            produtoJaExiste = true;
            break; 
        }
    }

    if (!produtoJaExiste) {
        addCarrinho(boloCenoura);
    }

    atualizarPainelPedidos();
    lblTotalPedido.setText("R$ " + calculaTotalPagamento());
    }//GEN-LAST:event_btBoloCenouraActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.setVisible(false);
        
        LoginCliente telaLogin = new LoginCliente();
        telaLogin.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btBoloCenoura;
    private javax.swing.JButton btCafeExpresso;
    private javax.swing.JButton btPaoDoce;
    private javax.swing.JButton btPaoDoceLiso;
    private javax.swing.JButton btPaoFrances;
    private javax.swing.JButton btPaoQueijo;
    private javax.swing.JButton btRosca;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lblTotalPedido;
    private javax.swing.JPanel painelPedidos;
    // End of variables declaration//GEN-END:variables
}
