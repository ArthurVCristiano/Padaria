package daos;

import connection.Conexao;
import entity.Produto;
import entity.Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author andre
 */
public class VendaDao {
  
    public Venda salvar(Venda venda) {
        Connection conexao = null;
        try{
            conexao = Conexao.getConnection();
            String sql = "insert into vendas (nome_cliente,valor_venda,form_pag) values(?,?,?)";
            
             PreparedStatement smt = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
             
             smt.execute();     
        } 
        catch (SQLException ex) {
            System.getLogger(ProdutoDao.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        return venda;
    }

    public List<Produto> consultar() {
        List<Produto> produtos = new ArrayList<>();
       Connection con = null;
      
       try{
        con = Conexao.getConnection();
        PreparedStatement smt = con.prepareStatement("select * from vendas");
        
        ResultSet rs = smt.executeQuery();
        
        
        while(rs.next()){
            //Venda venda = new Venda();
        }
       }catch(SQLException ex){
           throw new RuntimeException(ex.getMessage());
       }
       finally{
           Conexao.fecharConexao();
       }
       return produtos;
    }

    public void delete(int id) {
         Connection con = null;
       
       try{
        con = Conexao.getConnection();
        PreparedStatement smt = con.prepareStatement("delete from produtos where id_venda = " + id);
        
        ResultSet rs = smt.executeQuery();
        
        rs.next();

       }catch(SQLException ex){
           throw new RuntimeException(ex.getMessage());
       }
       finally{
           Conexao.fecharConexao();
       }
    }

    public Produto consultarPeloId(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
